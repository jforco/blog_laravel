@extends('templates.master')

@section('titulo', 'vacio')

@section('body')
	<br><br><br>
	pagina vacia
	<br><br><br>
@endsection
