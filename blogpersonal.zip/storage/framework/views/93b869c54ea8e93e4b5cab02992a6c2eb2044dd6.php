<?php $__env->startSection('body'); ?>

<section class="contenedor-central2">
    <div class="fondo-imagen" style="background-image: url('..<?php echo $__env->yieldContent('style-bg-imagen'); ?>')" !important;>
		<div>
			<br><br><br><br><br>
			<div class="row no-gutters">
				<div class="col-9 offset-3">
					<div class="titulo-seccion">
						<p class="text-white px-3 py-2 my-0 h5"><?php echo $__env->yieldContent('titulo-seccion'); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="contenedor-central2">
	<div class="row no-gutters">
		<div class="col-3 py-4">
			<nav class="nav flex-column ">
				<?php echo $__env->yieldContent('menu-seccion'); ?>
			</nav>
		</div>
		<div class="col-9">
			<?php echo $__env->yieldContent('contenido-seccion'); ?>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>