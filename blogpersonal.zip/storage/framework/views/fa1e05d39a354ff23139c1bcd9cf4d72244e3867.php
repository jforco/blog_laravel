<?php $__env->startSection('titulo', 'vacio'); ?>

<?php $__env->startSection('body'); ?>
	<br><br><br>
	pagina vacia
	<br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>