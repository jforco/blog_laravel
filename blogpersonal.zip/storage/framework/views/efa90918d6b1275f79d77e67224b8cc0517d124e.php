<?php $__env->startSection('titulo', 'Galeria de fotos'); ?>

<?php $__env->startSection('titulo-seccion', 'GALERIA DE FOTOS'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick.css')); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick-theme.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style-bg-imagen', '/img/moto1.jpg'); ?>
	


<?php $__env->startSection('menu-seccion'); ?>
	
	<a class="menu-opcion" href="<?php echo e(url('acerca-de')); ?>"><i class="fa fa-angle-right pr-2"></i>Acerca de Luis</a>
	<a class="menu-opcion" href="<?php echo e(url('acerca-de/hechos-divertidos')); ?>"><i class="fa fa-angle-right pr-2"></i>Hechos divertidos</a>
	<a class="menu-opcion menu-opcion-activo  menu-opcion-ultimo" href="<?php echo e(url('galeria-fotos')); ?>"><i class="fa fa-angle-right pr-2"></i>Galeria de Fotos</a>

	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-seccion'); ?>
	<div class="p-3">
		<div class="slider-for p-3">
			<div>
				<img width="100%" src="<?php echo e(asset('img/a1.jpg')); ?>">
			</div>
			<div>
				<img width="100%" src="<?php echo e(asset('img/a2.jpg')); ?>">
			</div>
			<div>
				<img width="100%" src="<?php echo e(asset('img/a3.jpg')); ?>">
			</div>
			<div>
				<img width="100%" src="<?php echo e(asset('img/bariloche.jpg')); ?>">
			</div>
			<div>
				<img width="100%" src="<?php echo e(asset('img/caribe.jpg')); ?>">
			</div>
			<div>
				<img width="100%" src="<?php echo e(asset('img/copacabana.jpg')); ?>">
			</div>
		</div>
		<div class="slider-nav px-5 py-3">
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/a1.jpg')); ?>">
			</div>
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/a2.jpg')); ?>">
			</div>
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/a3.jpg')); ?>">
			</div>
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/bariloche.jpg')); ?>">
			</div>
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/caribe.jpg')); ?>">
			</div>
			<div class="m-1">
				<img width="100%" src="<?php echo e(asset('img/copacabana.jpg')); ?>">
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script type="text/javascript" src="<?php echo e(asset('slick/slick.min.js')); ?>"></script>
	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.slider-for').slick({
			  	slidesToShow: 1,
			  	slidesToScroll: 1,
			  	arrows: false,
			  	fade: true,
			  	asNavFor: '.slider-nav'
			});
			$('.slider-nav').slick({
			  	slidesToShow: 3,
			  	slidesToScroll: 1,
			  	asNavFor: '.slider-for',
			  	centerMode: true,
			  	focusOnSelect: true,
			  	responsive: [
			    {
			      breakpoint: 900,
			      settings: {
			        slidesToShow: 2,
				  	slidesToScroll: 1,
				  	asNavFor: '.slider-for',
				  	centerMode: true,
				  	focusOnSelect: true
			      }
			    }
			  	]
			});
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>