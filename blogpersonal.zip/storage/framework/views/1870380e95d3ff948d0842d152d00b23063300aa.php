<?php $__env->startSection('titulo', 'Galeria de videos'); ?>

<?php $__env->startSection('titulo-seccion', 'GALERIA DE VIDEOS'); ?>

<?php $__env->startSection('style-bg-imagen', '/img/moto1.jpg'); ?>
	


<?php $__env->startSection('menu-seccion'); ?>
	
	<a class="menu-opcion" href="<?php echo e(url('acerca-de')); ?>"><i class="fa fa-angle-right pr-2"></i>Acerca de Luis</a>
	<a class="menu-opcion" href="<?php echo e(url('acerca-de/hechos-divertidos')); ?>"><i class="fa fa-angle-right pr-2"></i>Hechos divertidos</a>
	<a class="menu-opcion" href="<?php echo e(url('galeria-fotos')); ?>"><i class="fa fa-angle-right pr-2"></i>Galeria de Fotos</a>
	<a class="menu-opcion menu-opcion-activo menu-opcion-ultimo" href="<?php echo e(url('galeria-videos')); ?>"><i class="fa fa-angle-right pr-2"></i>Galeria de Videos</a>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-seccion'); ?>
	<div class="p-3">
		<h3>titulo</h3>
		<p>contenido</p>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>