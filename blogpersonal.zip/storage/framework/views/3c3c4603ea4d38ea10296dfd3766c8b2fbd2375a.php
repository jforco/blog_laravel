<?php $__env->startSection('titulo', 'Noticias'); ?>

<?php $__env->startSection('titulo-seccion', 'NOTICIAS'); ?>

<?php $__env->startSection('style-bg-imagen', '/img/moto1.jpg'); ?>
	


<?php $__env->startSection('menu-seccion'); ?>
	
	<a class="menu-opcion menu-opcion-activo" href="<?php echo e(url('noticias')); ?>"><i class="fa fa-angle-right pr-2"></i>Noticias</a>
	<a class="menu-opcion menu-opcion-ultimo" href="<?php echo e(url('eventos')); ?>"><i class="fa fa-angle-right pr-2"></i>Eventos</a>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-seccion'); ?>
	<div class="p-3">
		<?php $__empty_1 = true; $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		    <div class="row my-2">
		    	<div class="col-sm-4">
		    		<img width="100%" src="<?php echo e(Voyager::image(str_replace('.jpg','-cropped.jpg', $noticia->image))); ?>">
		    	</div>
		    	<div class="col-sm-8">
		    		<p class="my-0 h5 colorPrincipal"><?php echo e($noticia->title); ?></p>
		    		<p class="pequeño text-justify"><?php echo e($noticia->excerpt); ?></p>
		    		<a class="colorPrincipal" href="<?php echo e(url('/noticias/' . $noticia->slug )); ?>"><strong>Ver Noticia</strong></a>
		    	</div>
		    </div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		    <p>Aun no hay Publicaciones en esta sección.</p>
		<?php endif; ?>
		<br>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>