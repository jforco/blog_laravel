<?php $__env->startSection('titulo', 'Hechos Divertidos'); ?>

<?php $__env->startSection('titulo-seccion', 'HECHOS DIVERTIDOS'); ?>

<?php $__env->startSection('style-bg-imagen', '/img/moto1.jpg'); ?>
	


<?php $__env->startSection('menu-seccion'); ?>
	
	<a class="menu-opcion" href="<?php echo e(url('acerca-de')); ?>"><i class="fa fa-angle-right pr-2"></i>Acerca de Luis</a>
	<a class="menu-opcion menu-opcion-activo" href="<?php echo e(url('acerca-de/hechos-divertidos')); ?>"><i class="fa fa-angle-right pr-2"></i>Hechos divertidos</a>
	<a class="menu-opcion menu-opcion-ultimo" href="<?php echo e(url('galeria-fotos')); ?>"><i class="fa fa-angle-right pr-2"></i>Galeria de Fotos</a>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-seccion'); ?>
	<div class="p-3">
		<p class="pequeño">Siempre me preguntan qué altura tengo. A continuación hay algunos datos y cifras divertidas sobre la vida de Luis</p>
		<img width="100%" class="p-3" src="<?php echo e(asset('/img/infografia.png')); ?>">
		<br>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>