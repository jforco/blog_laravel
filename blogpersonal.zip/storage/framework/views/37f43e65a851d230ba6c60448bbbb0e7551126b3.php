<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8">
    </head>
    <style type="text/css">
    	
    </style>
    <body>
    	<h3>Contacto nuevo!</h3>
    	<br>
    	<h5><?php echo e($nombre); ?> <?php echo e($apellido); ?> te ha enviado un mensaje:</h5>
    	<br>
        <p>Motivo: <?php echo e($motivo); ?></p>
    	<p><?php echo e($mensaje); ?></p>
    	<strong>---Fin de Mensaje---</strong>
    	<p>Puedes responderle enviando un correo a la siguiente direccion:</p>
    	<h3><?php echo e($correo); ?></h3>
    </body>
</html>