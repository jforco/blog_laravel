<?php $__env->startSection('titulo', 'Consejos de Negocio'); ?>

<?php $__env->startSection('titulo-seccion', 'CONSEJOS DE NEGOCIO'); ?>

<?php $__env->startSection('style-bg-imagen', '/img/moto1.jpg'); ?>
	


<?php $__env->startSection('menu-seccion'); ?>
	
	<a class="menu-opcion menu-opcion-activo" href="<?php echo e(url('consejos-negocio')); ?>"><i class="fa fa-angle-right pr-2"></i>Consejos de Negocio</a>
	<a class="menu-opcion" href="<?php echo e(url('guia-negocio')); ?>"><i class="fa fa-angle-right pr-2"></i>Guia de negocios</a>
	<a class="menu-opcion menu-opcion-ultimo" href="<?php echo e(url('preguntas-frecuentes')); ?>"><i class="fa fa-angle-right pr-2"></i>Preguntas Frecuentes</a>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-seccion'); ?>
	<div class="p-3">
		<h3>Consejos formados de años de experiencia</h3>
		<h5 class="colorPrincipal">CONSEJO NRO X</h5>
		<p class="pequeño text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam finibus tincidunt ipsum fermentum placerat. Quisque nec mollis eros. Fusce nulla velit, sagittis et feugiat scelerisque, malesuada eu est. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>

		<h5 class="colorPrincipal">CONSEJO NRO X</h5>
		<p class="pequeño text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam finibus tincidunt ipsum fermentum placerat. Quisque nec mollis eros. Fusce nulla velit, sagittis et feugiat scelerisque, malesuada eu est. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>

		<h5 class="colorPrincipal">CONSEJO NRO X</h5>
		<p class="pequeño text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam finibus tincidunt ipsum fermentum placerat. Quisque nec mollis eros. Fusce nulla velit, sagittis et feugiat scelerisque, malesuada eu est. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>

		<h5 class="colorPrincipal">CONSEJO NRO X</h5>
		<p class="pequeño text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam finibus tincidunt ipsum fermentum placerat. Quisque nec mollis eros. Fusce nulla velit, sagittis et feugiat scelerisque, malesuada eu est. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>

		<h5 class="colorPrincipal">CONSEJO NRO X</h5>
		<p class="pequeño text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam finibus tincidunt ipsum fermentum placerat. Quisque nec mollis eros. Fusce nulla velit, sagittis et feugiat scelerisque, malesuada eu est. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>

	</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('templates.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>