<?php $__env->startSection('titulo', 'Entradas del Blog'); ?>

<?php $__env->startSection('body'); ?>

	<div class="contenedor-central">
		<div class="row py-4">
			<div class="col-sm-9">
				<div class="row no-gutters">
					<?php $__empty_1 = true; $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		    		<div class="col-sm-6 col-lg-4 mb-3">
		    			<div class="pr-3">
		    				<div class="card">
		                        <img width="100%" src="<?php echo e(Voyager::image(str_replace('.jpg','-cropped.jpg', $entrada->image))); ?>">
		                        <div class="card-body">
		                            <h5 class="card-title"><?php echo e($entrada->title); ?></h5>
		                            <p class="small text-justify"><?php echo e(substr($entrada->excerpt, 0, 100)); ?>...</p>
		                            <a href="<?php echo e(url('/blog/' . $entrada->slug )); ?>" class="btn btn-primary py-0 px-1"><small>Leer mas...</small></a>
		                        </div>
		                    </div>
		    			</div>
		    		</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<br>
					<p>No hay entradas aun.</p>
					<br>
					<?php endif; ?>
					<br>
					<?php echo e($entradas->links()); ?>

				</div>
			</div>	
			<div class="col-sm-3">
				<?php echo $__env->make('facebook', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>

				
	</div>

	<div id="fb-root"></div>
	<script>
	    (function(d, s, id) {
	        var js, fjs = d.getElementsByTagName(s)[0];
	        if (d.getElementById(id)) return;
	        js = d.createElement(s); js.id = id;
	        js.src = 'https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v2.12&appId=175543323021297';
	        fjs.parentNode.insertBefore(js, fjs);
	    }   (document, 'script', 'facebook-jssdk'));
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>